public class Latihan03d {
    public static void main(String[] args) {
        int a = 17;
        int b = 8;
        int c = 5;

        System.out.println("a & b = " + (a & b));
        System.out.println("a | c = " + (a | c));
        System.out.println("a ^ b = " + (a ^ b));

        System.out.println("\n=======================================");
        System.out.println("Program  : Latihan03a");
        System.out.println("NIM      : A12.2020.06492");
        System.out.println("Nama     : Andreas Marcelino Andriawan");
    }
}

// Output dari program diatas
// a & b = 0
// a | c = 21
// a ^ b = 25

// =======================================
// Program  : Latihan03a
// NIM      : A12.2020.06492
// Nama     : Andreas Marcelino Andriawan