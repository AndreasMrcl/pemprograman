public class Latihan03a {
    public static void main(String[] args) {
        int x = 5;

        System.out.println("x        = " + x); // menampilkan atau mencetak x = 5
        System.out.println("x += 1   = " + (x += 1)); // menampilkan atau mencetak x += 1 = 6, sama dengan x = x + 1
        // x = 6
        System.out.println("x -= 2   = " + (x -= 2)); // menampilkan atau mencetak x -= 2 = 4, sama dengan x = x - 2
        // x = 4
        System.out.println("x *= 3   = " + (x *= 3)); // menampilkan atau mencetak x *= 3 = 12, sama dengan x = x * 3
        // x = 12
        System.out.println("x /= 4   = " + (x /= 4)); // menampilkan atau mencetak x /= 4 = 3, sama dengan x = x / 4 
        // x = 3
        System.out.println("x %= 5   = " + (x %= 5)); // menampilkan atau mencetak x %= 5 = 3, sama dengan x = x % 5

        System.out.println("\n=======================================");
        System.out.println("Program  : Latihan03a");
        System.out.println("NIM      : A12.2020.06492");
        System.out.println("Nama     : Andreas Marcelino Andriawan");
    }
}

// Output dari program diatas
// x        = 5
// x += 1   = 6
// x -= 2   = 4
// x *= 3   = 12
// x /= 4   = 3
// x %= 5   = 3

// =======================================
// Program  : Latihan03a
// NIM      : A12.2020.06492
// Nama     : Andreas Marcelino Andriawan