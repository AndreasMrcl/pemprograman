public class Latihan03a {
    public static void main(String[] args) {
        int x = 5;

        System.out.println("x        = " + x);
        System.out.println("x += 1   = " + (x += 1));
        System.out.println("x -= 1   = " + (x -= 2));
        System.out.println("x *= 1   = " + (x *= 3));
        System.out.println("x /= 1   = " + (x /= 4));
        System.out.println("x %= 1   = " + (x %= 5));

        System.out.println("\n=======================================");
        System.out.println("Program  : Latihan03a");
        System.out.println("NIM      : A12.2020.06492");
        System.out.println("Nama     : Andreas Marcelino Andriawan");
    }
}

// Output dari program diatas
// x        = 5
// x += 1   = 6
// x -= 1   = 4
// x *= 1   = 12
// x /= 1   = 3
// x %= 1   = 3

// =======================================
// Program  : Latihan03a
// NIM      : A12.2020.06492
// Nama     : Andreas Marcelino Andriawan