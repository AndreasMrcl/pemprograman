public class Latihan03g {
    public static void main(String[] args) {
        int x1, x2, x3, x4, x5;

        x1 = 5 + 7 * 2;
        x2 = (5 + 7) * 2;
        x3 = 5 + 7 * 2 - 1;
        x4 = (5 + 7) * (2 - 1);
        x5 = 1 + 2 - 3 * 4 % 5;

        System.out.println("5 + 7 * 2         : " + ( x1 ));
        System.out.println("(5 + 7) * 2       : " + ( x2 ));
        System.out.println("5 + 7 * 2 - 1     : " + ( x3 ));
        System.out.println("(5 + 7) * (2 - 1) : " + ( x4 ));
        System.out.println("1 + 2 - 3 * 4 % 5 : " + ( x5 ));

        System.out.println("\n=======================================");
        System.out.println("Program  : Latihan03a");
        System.out.println("NIM      : A12.2020.06492");
        System.out.println("Nama     : Andreas Marcelino Andriawan");
    }
}

// Output dari program diatas
// 5 + 7 * 2         : 19
// (5 + 7) * 2       : 24
// 5 + 7 * 2 - 1     : 18
// (5 + 7) * (2 - 1) : 12
// 1 + 2 - 3 * 4 % 5 : 1

// =======================================
// Program  : Latihan03a
// NIM      : A12.2020.06492
// Nama     : Andreas Marcelino Andriawan