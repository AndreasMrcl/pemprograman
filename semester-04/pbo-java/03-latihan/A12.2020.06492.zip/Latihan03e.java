public class Latihan03e {
    public static void main(String[] args) {
        int a = 8;
        int b = 20;

        System.out.println("Nilai a    : " + ( a ));
        System.out.println("Nilai b    : " + ( b ));
        System.out.println("Hasil a>>1 : " + ( a>>1 ));
        System.out.println("Hasil a>>2 : " + ( a>>2 ));
        System.out.println("Hasil b<<1 : " + ( b<<1 ));
        System.out.println("Hasil b<<2 : " + ( b<<2 ));

        System.out.println("\n=======================================");
        System.out.println("Program  : Latihan03a");
        System.out.println("NIM      : A12.2020.06492");
        System.out.println("Nama     : Andreas Marcelino Andriawan");
    }
}

// Output dari program diatas
// Nilai a    : 8
// Nilai b    : 20
// Hasil a>>1 : 4
// Hasil a>>2 : 2
// Hasil b<<1 : 40
// Hasil b<<2 : 80

// =======================================
// Program  : Latihan03a
// NIM      : A12.2020.06492
// Nama     : Andreas Marcelino Andriawan